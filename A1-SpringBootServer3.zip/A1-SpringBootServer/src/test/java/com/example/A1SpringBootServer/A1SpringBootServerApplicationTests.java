package com.example.A1SpringBootServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A1SpringBootServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
