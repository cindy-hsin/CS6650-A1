package com.example.A1SpringBootServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A1SpringBootServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(A1SpringBootServerApplication.class, args);
	}

}
